﻿namespace Vaquinha.Domain.ViewModels
{
    public class CausaViewModel
    {
        public string Nome { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
    }
}